# Changelog — DHG Core 4

## [0.1.0] — Initial Release

### Added
- FastAPI backend with CRUD asset API.
- React + Vite + TS frontend.
- PostgreSQL with pgvector enabled.
- Docker Compose stack.
- Complete documentation set.
