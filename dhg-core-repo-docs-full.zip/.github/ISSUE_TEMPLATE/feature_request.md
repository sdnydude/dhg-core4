---
name: Feature request
about: Suggest a new feature for DHG Core 4
labels: enhancement
---

## Description
What feature would you like?

## Motivation
Why is it needed?

## Proposed Solution
Your preferred approach.

## Additional context
