# Summary

Describe the change in a sentence or two.

## Changes

- [ ] Backend
- [ ] Frontend
- [ ] Infra / Docker
- [ ] Docs

## Testing

Describe how you tested this change.

- [ ] Docker compose up
- [ ] Backend endpoint tested
- [ ] Frontend page tested
- [ ] Other (describe)

## Notes

Any extra context, risks, or follow-ups.
